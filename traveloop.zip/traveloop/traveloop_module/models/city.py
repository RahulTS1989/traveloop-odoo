from odoo import fields, models


class TravelStop(models.Model):
    _name = "traveloop.stop"
    _description = "Travel Stop (City/Leg)"
    _order = "arrival_date asc, id asc"

    trip_id = fields.Many2one("traveloop.trip", required=True, ondelete="cascade")

    sequence = fields.Integer(default=10)

    city_name = fields.Char(required=True)
    country = fields.Char()

    arrival_date = fields.Date()
    departure_date = fields.Date()

    activity_ids = fields.One2many("traveloop.activity", "stop_id")

