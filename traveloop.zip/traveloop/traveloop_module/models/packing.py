from odoo import fields, models


class PackingItem(models.Model):
    _name = "traveloop.packing"
    _description = "Packing Checklist"

    trip_id = fields.Many2one("traveloop.trip", required=True, ondelete="cascade")

    name = fields.Char(required=True)
    packed = fields.Boolean(default=False)

    category = fields.Selection(
        [
            ("clothes", "Clothes"),
            ("documents", "Documents"),
            ("electronics", "Electronics"),
            ("toiletries", "Toiletries"),
            ("other", "Other"),
        ],
        default="other",
    )

