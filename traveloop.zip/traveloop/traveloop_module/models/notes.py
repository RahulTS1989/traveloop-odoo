from odoo import fields, models


class TripNotes(models.Model):
    _name = "traveloop.notes"
    _description = "Trip Notes / Journal"
    _order = "create_date desc, id desc"

    trip_id = fields.Many2one("traveloop.trip", required=True, ondelete="cascade")

    title = fields.Char(required=True)
    content = fields.Text()

    day_date = fields.Date(string="Day")

