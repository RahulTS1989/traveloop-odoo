from odoo import fields, models


class TravelBudgetLine(models.Model):
    _name = "traveloop.budget"
    _description = "Travel Budget Line"

    trip_id = fields.Many2one("traveloop.trip", required=True, ondelete="cascade")

    line_type = fields.Selection(
        [
            ("transport", "Transport"),
            ("hotel", "Hotel"),
            ("activities", "Activities"),
            ("food", "Food"),
        ],
        required=True,
    )

    name = fields.Char(required=True)
    amount = fields.Monetary(currency_field="currency_id", default=0.0)
    currency_id = fields.Many2one(
        related="trip_id.currency_id", store=True, readonly=True
    )

