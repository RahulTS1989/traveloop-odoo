from odoo import fields, models


class TravelActivity(models.Model):
    _name = "traveloop.activity"
    _description = "Trip Activity"
    _order = "estimated_cost desc, id asc"

    name = fields.Char(required=True)
    category = fields.Selection(
        [
            ("food", "Food"),
            ("adventure", "Adventure"),
            ("shopping", "Shopping"),
            ("culture", "Culture"),
            ("other", "Other"),
        ],
        default="other",
    )

    estimated_cost = fields.Monetary(
        currency_field="currency_id", default=0.0
    )
    currency_id = fields.Many2one(
        "res.currency",
        related="trip_id.currency_id",
        store=True,
        readonly=True,
    )

    trip_id = fields.Many2one("traveloop.trip", required=True, ondelete="cascade")
    stop_id = fields.Many2one("traveloop.stop", ondelete="set null")

