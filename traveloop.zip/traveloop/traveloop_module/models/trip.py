from odoo import api, fields, models


class TravelTrip(models.Model):
    _name = "traveloop.trip"
    _description = "Travel Trip"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(required=True, tracking=True)
    description = fields.Text()

    start_date = fields.Date()
    end_date = fields.Date()

    currency_id = fields.Many2one(
        "res.currency",
        default=lambda self: self.env.company.currency_id.id,
        readonly=True,
    )

    budget_transport = fields.Monetary(currency_field="currency_id", default=0.0)
    budget_hotel = fields.Monetary(currency_field="currency_id", default=0.0)
    budget_activities = fields.Monetary(currency_field="currency_id", default=0.0)
    budget_food = fields.Monetary(currency_field="currency_id", default=0.0)

    budget_total = fields.Monetary(
        currency_field="currency_id",
        compute="_compute_budget_total",
        store=True,
    )

    user_id = fields.Many2one("res.users", default=lambda self: self.env.user)

    stop_ids = fields.One2many("traveloop.stop", "trip_id")

    note_ids = fields.One2many("traveloop.notes", "trip_id")
    packing_ids = fields.One2many("traveloop.packing", "trip_id")
    activity_ids = fields.One2many(
        "traveloop.activity", "trip_id", string="Activities"
    )

    @api.depends(
        "budget_transport",
        "budget_hotel",
        "budget_activities",
        "budget_food",
    )
    def _compute_budget_total(self):
        for rec in self:
            rec.budget_total = (
                rec.budget_transport
                + rec.budget_hotel
                + rec.budget_activities
                + rec.budget_food
            )

    public_share_token = fields.Char(index=True, readonly=True)

    def _ensure_share_token(self):
        for rec in self:
            if not rec.public_share_token:
                rec.public_share_token = fields.Char(
                    default=fields.UUID(),  # best-effort; will be set on create
                )

    def get_public_url(self):
        self.ensure_one()
        # token might be absent on very old records; use name as fallback
        token = self.public_share_token or ""
        return f"/trip/public/{self.id}?token={token}"

