from odoo import fields, models


class TraveloopUserProfile(models.Model):
    _name = "traveloop.user_profile"
    _description = "Traveloop User Profile"
    _rec_name = "display_name"

    user_id = fields.Many2one("res.users", required=True, ondelete="cascade")

    display_name = fields.Char(compute="_compute_display_name", store=True)
    bio = fields.Text()

    favorite_cities = fields.Char(
        help="Comma-separated list of favorite cities (hackathon simplification)."
    )

    def _compute_display_name(self):
        for rec in self:
            rec.display_name = rec.user_id.name

    _sql_constraints = [
        (
            "traveloop_user_profile_unique_user",
            "unique(user_id)",
            "Each user can have only one profile.",
        )
    ]

