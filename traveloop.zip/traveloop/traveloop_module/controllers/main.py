from odoo import http
from odoo.http import request


class TraveloopPublicController(http.Controller):
    @http.route(
        "/trip/public/<int:trip_id>",
        type="http",
        auth="public",
        website=True,
        csrf=False,
    )
    def trip_public(self, trip_id, token=None, **kwargs):
        Trip = request.env["traveloop.trip"].sudo()
        trip = Trip.browse(trip_id)
        if not trip.exists():
            return request.not_found()

        # Minimal token check (hackathon). In real usage validate properly.
        if trip.public_share_token and token and token != trip.public_share_token:
            return request.not_found()

        # Render a simple page using an inline QWeb template.
        values = {"trip": trip}
        return request.render("traveloop.trip_public_page", values)

