# Traveloop (Odoo Hackathon Project)

Smart multi-city travel planning platform.

## Stack
- Odoo 17/18 (Community)
- Python models
- PostgreSQL
- Odoo XML views
- Optional OWL/JS (kept minimal for hackathon MVP)

## Module layout
`traveloop_module/`
- models/
- views/
- security/
- controllers/
- static/

## Local development
1. Copy module to your Odoo custom addons path:
   - `cp -r traveloop_module <ODOO_CUSTOM_ADDONS_PATH>/`
2. Install/update module in Odoo:
   - `-u traveloop_module` (depends on your module name)

## Quick run (example)
```bash
python odoo-bin -d traveloop_db -u traveloop_module --addons-path=addons,<custom_addons_path>
```

## Notes
This repository currently contains the core MVP scaffolding (models + basic views + menu + access rules).

